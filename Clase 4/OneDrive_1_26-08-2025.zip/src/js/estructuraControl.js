let edad = 18;

if (edad < 18) {
  console.log("Eres menor de edad");
} else if (edad === 18) {
  console.log("¡Acabas de cumplir 18!");
} else {
  console.log("Eres mayor de edad");
}


// Imprimir números del 1 al 5
for (let i = 1; i <= 5; i++) {
    console.log(i);
  }

// Contar hasta 3
let contador = 1;
while (contador <= 3) {
  console.log(contador);
  contador++;
}